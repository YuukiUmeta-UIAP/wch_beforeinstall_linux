This empty directory is to fix this issuu:
https://github.com/openwch/arduino_core_ch32/issues/44